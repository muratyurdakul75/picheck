Pi Check 1.2.2 

What's new in the app

1. Added page showing availability rates. (Availability page)
2. Added port control feature.  (Settings page)
3. The time calculation has been corrected to give more accurate results when Analyzing by Date. (Analysis page)
4. Block numbers have been changed to get from the api link instead of the dashboard page. (Monitor page)
5. Performance improvements have been made.
6. Added some checks to prevent crashes.